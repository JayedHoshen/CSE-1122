#include<bits/stdc++.h>
 using namespace std;

 class Date
 {
     int date;
     int month;
     int year;
 public:
    void setDate()          //input date here
    {
        cout<< "Enter date: "<<endl;
        cin>>date;
        cout<< "Enter Month :";
        cin>>month;
        cout<< "Enter Year ";
        cin>> year;

    }
    //check the date valid or invalid
    void validate(int day, int month, int year)
    {
        day = date;             //assign input data
        month= month;
        year= year;
        if((month==1 || month==3 || month==5|| month==7|| month==8||month==10||month==12) && day>0 && day<=31)              //the month of 31
         cout<<"It is valid date";
         else
     if(month==4 || month==6 || month==9|| month==11 && day>0 && day<=30)                   //the month of 30
            cout<<"It is Valid date";
         else
            if(month==2)
               {
               if((year%400==0 || (year%100!=0 && year%4==0)) && day>0 && day<=29)              //check leap year
                 cout<<"It is Valid date";
               else if(day>0 && day<=28)
                  cout<<"It is Valid";
               else
                  cout<<"It is Invalid date;
               }
         else
               cout<<"It is Invalid date";
      }




 };
 int main()
 {
     Date objdate;      //create object
     objdate.setDate();
   objdate.validate(04,12,2002);            //demo data pass


 }
