#include<bits/stdc++.h>
 using namespace std;
 class STUDENT
 {

 private:
    string sname;
    int marks[5];
    float total;
    float Tmax;

 public:
    void getdata()          //input  data here
    {
        cout<<"Enter Student name: ";
        cin>>sname;
        cout<<"Enter marks: ";
        for(int i=0;i<5;i++)
        {
            cin>>marks[i];

        }
    }
    void compute()          //to compute data
    {
        float sum=0;
        for(int i=0;i<5;i++)
        {
            sum+=marks[i];
        }
        total = sum;
        Tmax= (total/(5*120))*100;
    }
    void display()          //to display data
    {
        cout<<"Name is :"<<sname<<endl;
        cout<<"Total marks is "<<total<<endl;
        cout<<"Percentage is "<<Tmax<< "%"<<endl;

    }
 };
 int main()
 {
     STUDENT s1;        //create object
     s1.getdata();
     s1.compute();
     s1.display();
 }
