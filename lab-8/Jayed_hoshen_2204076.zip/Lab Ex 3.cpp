#include<bits/stdc++.h>
using namespace std;
class swapClass
{
public:
    //for integer variable
    void swapfun(int &x, int &y)        //using pointer and reference type variable
    {
        int temp;
        temp = x;
        x=y;
        y=temp;

    }
    //for float variable
    void swapfun(float &f1, float &f2)           //using pointer and reference type variable
    {
        float temp;
        temp = f1;
        f1=f2;
        f2=temp;

    }
    //for character variable
    void swapfun(char &c1, char &c2)             //using pointer and reference type variable
    {
        char temp;
        temp = c1;
        c1=c2;
        c2=temp;

    }

};
int main()
{
    int a=10,b=20;
    float x=10.10, y=20.20;
    char c='a', d='b';
    swapClass s;
    s.swapfun(a,b);             //call integer function
    s.swapfun(x,y);             //call float function
    s.swapfun(c,d);             //call character function
    // after swap variables
    cout<<a<<" "<<b<<endl;
    cout<<x<<"  "<<y<<endl;
    cout<<c<<"  "<<d<<endl;
}
