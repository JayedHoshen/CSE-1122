#include<bits/stdc++.h>
using namespace std;
class Point
{
private :
    int x;
    int y;
public:
    Point(int a, int b)         //parameterized constructor
    {
        x=a;
        y=b;

    }
    void getDistance(int x2, int y2)        //method overloading, integer call
    {
        double dis= sqrt((x2-x)*(x2-x)+(y2-y)*(y2-y));
        cout<<"Total distance of int "<<dis<<endl;
    }
        void getDistance(double x2, double y2)          //method overloading double call
    {
        double dis= sqrt((x2-x)*(x2-x)+(y2-y)*(y2-y));
        cout<<"Total distance of double "<<dis<<endl;
    }
};
int main()
{
    Point p1(10,20);            //create object and automatic called method
    p1.getDistance(20.20,30.20);
    p1.getDistance(20,30);

}
