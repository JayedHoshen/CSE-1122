#include<bits/stdc++.h>
using namespace std;
class EMPLOYEE          //create class
{
private:
    int empCode;
    string empName;

public:
    void getData()          //for input data
    {
        cout<<"Enter Employee Name: "<<endl;
        cin>>empName;
        cout<<"Enter Employee code"<<endl;
        cin>>empCode;
    }
    void display()          //for output data
    {
        cout<<"Employee name is: "<<empName<<endl;
        cout<<"Employee code is: " <<empCode<<endl;
    }
};
int main()
{
    cout<< "Enter employee information: \n\n"<<endl;
    EMPLOYEE Emp[7];        //create an object array
    for(int i=0; i<7; i++)
    {
        cout<< "Employee "<<i+1<< " information"<<endl;
        Emp[i].getData();       //input data using loop calling object
    }
    for(int i=0; i<7; i++)
    {
        Emp[i].display();           // display data using loop
    }
    return 0;

}
